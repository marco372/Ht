from hawk_user_manager import HawkUserManager
import time

# Création de l'instance
user_mgr = HawkUserManager()

# Nom d'utilisateur et mot de passe de test
username = "test_user"
password = "secure123"

print(f"Création de l'utilisateur '{username}'...")

# Étape 1 : Création
created = user_mgr.create_user(username, password)
print("Création:", "OK" if created else "Déjà existant")

# Étape 2 : Authentification
print("\nAuthentification...")
token = user_mgr.authenticate_user(username, password)
if token:
    print("Token obtenu:", token[:10], "...")  # Affichage partiel
else:
    print("Échec d'authentification.")

# Étape 3 : Validation du token
if token:
    print("\nValidation du token...")
    valid = user_mgr.validate_token(username, token)
    print("Token valide:", valid)

# Étape 4 : Simuler expiration essai gratuit (optionnel)
print("\nMise à jour des statuts utilisateurs (vérification expiration d'essai)...")
user_mgr.update_status()
print("Mise à jour faite.")

# Étape 5 : Paiement simulé
print("\nEnregistrement d’un paiement fictif...")
user_mgr.record_payment(username, commission=5.75)
print("Paiement enregistré avec 5.75$ de commission.")

# Étape 6 : Info utilisateur
print("\nInfos utilisateur après paiement:")
info = user_mgr.get_user_info(username)
print(info)

# Étape 7 : Blocage de l’utilisateur
print("\nBlocage de l'utilisateur...")
user_mgr.block_user(username)
print("Utilisateur bloqué.")

# Vérifier si bloqué
print("\nNouvelle tentative de connexion après blocage...")
token_after_block = user_mgr.authenticate_user(username, password)
print("Token après blocage:", token_after_block if token_after_block else "Refusé")
