import requests

BASE_URL = "http://127.0.0.1:5000"

# Étape 1 : Créer un utilisateur
print(">>> Création d'un nouvel utilisateur...")
register_payload = {
    "username": "test_user",
    "password": "secure123"
}
r = requests.post(f"{BASE_URL}/register", json=register_payload)
print(f"Réponse inscription: {r.status_code}, {r.json()}")

# Étape 2 : Connexion pour obtenir le token
print("\n>>> Connexion de l'utilisateur...")
login_payload = {
    "username": "test_user",
    "password": "secure123"
}
r = requests.post(f"{BASE_URL}/login", json=login_payload)
print(f"Réponse connexion: {r.status_code}, {r.json()}")

if r.status_code == 200 and "token" in r.json():
    token = r.json()["token"]

    # Étape 3 : Lancer l'analyse
    print("\n>>> Lancement d'une analyse crypto...")
    headers = {"Authorization": token}
    analyse_payload = {
        "cryptos": ["BTC", "ETH", "SOL"]
    }
    r = requests.post(f"{BASE_URL}/analyze", json=analyse_payload, headers=headers)
    print(f"Réponse analyse: {r.status_code}")
    try:
        print(r.json())
    except Exception as e:
        print("Erreur lors du décodage JSON:", str(e))
else:
    print(">>> Impossible de continuer : authentification échouée.")
