import os
import hashlib

def firewall_check():
    print("[FIREWALL] Scan SHA256...")
    for f in os.listdir():
        if f.endswith(".py"):
            try:
                with open(f, "rb") as file:
                    content = file.read()
                    checksum = hashlib.sha256(content).hexdigest()
                    print(f"{f} : {checksum[:12]}...")
            except Exception as e:
                print(f"Erreur sur {f} : {e}")

def honeypot_trap():
    fake_file = "honeypot_access_log.txt"
    try:
        with open(fake_file, "w") as f:
            f.write("ALERTE : tentative de connexion non autorisée.\n")
        print("[HONEYPOT] Leurre actif :", fake_file)
    except Exception as e:
        print(f"Erreur honeypot : {e}")
