import os, json, hashlib
import falcon_scraper_ai
from falcon_linker import link_code
from falcon_repair import auto_repair
from falcon_trainer import train_model
from falcon_guardian import firewall_check, honeypot_trap
from falcon_knowledge_engine import adapt_from_openai, build_internal_ai
from falcon_neuroforge import neuro_builder

neuro_builder()
import subprocess
import threading


def falcon_core():
    firewall_check()
    honeypot_trap()
    scan_files = [f for f in os.listdir() if f.endswith((".py", ".json"))]
    for file in scan_files:
        link_code(file)
        auto_repair(file)
    adapt_from_openai()
    train_model()
    build_internal_ai()
    print("[FalconCore] Surveillance active & IA en autonomie totale.")


# === INTÉGRATION STRATÉGIQUE AVANCÉE DE HAWKTRADER ===


def upgrade_hawktrader_in_background():
    print(
        "[FalconCoreAI -> HawkTrader] Lancement du processus d'amélioration constante via HawkUpgradeAI..."
    )
    try:
        process = subprocess.Popen(
            ["python", "script_AI_upgrade_for_Hawk.py"],
            cwd="./Falconcore",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        def monitor_upgrade():
            for line in process.stdout:
                print("[HawkUpgradeAI]", line.decode().strip())

        threading.Thread(target=monitor_upgrade, daemon=True).start()

    except Exception as e:
        print(f"[ERREUR] Échec du lancement de l’amélioration HawkTrader : {str(e)}")


# Appel automatique au démarrage de FalconCoreAI
upgrade_hawktrader_in_background()

if __name__ == "__main__":
    falcon_core()
