import os, json, hashlib, subprocess, threading, time
from falcon_scraper_ai import dynamic_scrape
from falcon_repair import auto_repair
from falcon_linker import link_code
from falcon_trainer import train_model
from falcon_guardian import firewall_check, honeypot_trap
from falcon_knowledge_engine import adapt_from_openai, build_internal_ai
from falcon_dashboard import refresh_dashboard
from falcon_supervisor import decision_engine
from falcon_chat import chat_with_ai
from falcon_version import save_version, rollback_version
from falcon_sync import sync_all_units
from falcon_neuroforge import neuro_builder
import os
import shutil
import datetime

# === INIT & NEURO START ===
neuro_builder()
firewall_check()
honeypot_trap()


# === SCAN & REPAIR ===
def scan_and_repair():
    for f in os.listdir():
        if f.endswith((".py", ".json")):
            link_code(f)
            auto_repair(f)


# === DECISION & ADAPTATION ===
def strategic_ai():
    adapt_from_openai()
    train_model()
    build_internal_ai()
    decision_engine()


# === CHAT AI MODULE ===
def chat_loop():
    while True:
        chat_with_ai()
        time.sleep(10)


# === DASHBOARD SYNC ===
def dashboard_sync():
    while True:
        refresh_dashboard()
        time.sleep(30)


def auto_upgrade_dashboard():
    print(
        "[AutoDashboardUpgrade] Analyse du dossier HawkTrader pour détecter le dashboard..."
    )
    try:
        ht_files = os.listdir("../HawkTrader")  # Chemin relatif depuis Falconcore
        dashboard_file = None

        for file in ht_files:
            if "dash" in file.lower() and file.endswith(".py"):
                dashboard_file = file
                break

        if dashboard_file:
            full_path = f"../HawkTrader/{dashboard_file}"

            # Sauvegarde avant modification
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"../HawkTrader/backups/{dashboard_file}_{timestamp}"
            os.makedirs(os.path.dirname(backup_path), exist_ok=True)
            shutil.copy(full_path, backup_path)
            print(f"[Backup] Sauvegarde créée : {backup_path}")

            with open(full_path, "r") as f:
                code = f.read()

            # Amélioration automatique du fichier (simple exemple de traitement)
            if "# [AI-Enhanced]" not in code:
                code += "\n\n# [AI-Enhanced] Auto-optimisation FalconCore appliquée.\n"
                with open(full_path, "w") as f:
                    f.write(code)
                print(
                    f"[AutoDashboardUpgrade] Amélioration appliquée à : {dashboard_file}"
                )
            else:
                print(f"[AutoDashboardUpgrade] Déjà optimisé : {dashboard_file}")
        else:
            print(
                "[AutoDashboardUpgrade] Aucun fichier dashboard détecté dans HawkTrader."
            )

    except Exception as e:
        print(f"[Erreur] Dashboard Upgrade : {str(e)}")


# === SCRAPER DYNAMIQUE ===
def start_scraper():
    dynamic_scrape()


# === VERSIONING AUTOMATIQUE ===
def version_control():
    save_version()
    rollback_version()


# === UPGRADE HAWKTRADER EN THREAD ===
def hawk_upgrade_cycle():
    try:
        p = subprocess.Popen(
            ["python", "script_AI_upgrade_for_Hawk.py"],
            cwd="./Falconcore",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        def monitor():
            for l in p.stdout:
                print("[HawkUpgradeAI]", l.decode().strip())

        threading.Thread(target=monitor, daemon=True).start()
    except Exception as e:
        print(f"[ERREUR Upgrade] {e}")


# === THREAD MANAGEMENT ===
def thread_core():
    threading.Thread(target=chat_loop, daemon=True).start()
    threading.Thread(target=dashboard_sync, daemon=True).start()
    threading.Thread(target=start_scraper, daemon=True).start()
    threading.Thread(target=hawk_upgrade_cycle, daemon=True).start()


# === MAIN CORE ===
def master_ai():
    print("[MASTER AI] Initialisation complÃ¨te.")
    scan_and_repair()
    strategic_ai()
    version_control()
    sync_all_units()
    thread_core()
    print("[MASTER AI] Autonomie totale activÃ©e. Surveillance continue.")


if __name__ == "__main__":
    master_ai()
auto_upgrade_dashboard()
