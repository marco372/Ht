import os
import hashlib

def firewall_check():
    print("[Guardian] Vérification des fichiers sensibles...")
    for f in os.listdir():
        if f.endswith(".py"):
            with open(f, "rb") as file:
                content = file.read()
                checksum = hashlib.sha256(content).hexdigest()
                print(f"{f} => SHA256: {checksum[:12]}...")

def honeypot_trap():
    print("[Honeypot] Déploiement du leurre actif...")
    fake_file = "fake_admin_panel.py"
    with open(fake_file, "w") as f:
        f.write("# honeypot\nprint('Accès refusé ! Alerte enregistrée.')")
    print(f"[Honeypot] {fake_file} créé comme appât.")
