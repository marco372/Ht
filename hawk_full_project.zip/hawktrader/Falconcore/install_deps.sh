#!/usr/bin/env bash
set -e

echo "1) Installation des paquets Python natifs via pkg…"
pkg update -y
pkg install -y python python-dev clang fftw libzmq libcrypt libxml2 libxslt
pkg install -y python-numpy python-pandas python-scipy python-scikit-learn

echo "2) Installation des modules PyPI via pip…"
for pkg in requests flask watchdog schedule python-telegram-bot ; do
  echo "pip install $pkg"
  pip install "$pkg"
done

echo "✅ Dépendances installées."
