import os
import time
import json
import hashlib
import logging
import socket
from datetime import datetime
from cryptography.fernet import Fernet
from hawk_wallet_manager import secure_wallet_access

# Initialisation du logger
logger = logging.getLogger("hawk_defense_ai")
logger.setLevel(logging.INFO)
fh = logging.FileHandler("logs/hawk_defense_ai.log")
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

# Chargement ou création de la clé de cryptage pour les logs sensibles
if not os.path.exists("logs/defense.key"):
    with open("logs/defense.key", "wb") as key_file:
        key_file.write(Fernet.generate_key())

with open("logs/defense.key", "rb") as key_file:
    encryption_key = key_file.read()

fernet = Fernet(encryption_key)

# IA mémoire adaptative des attaques
if not os.path.exists("logs/attacks_memory.json"):
    with open("logs/attacks_memory.json", "w") as f:
        json.dump([], f)

def load_attack_memory():
    with open("logs/attacks_memory.json", "r") as f:
        return json.load(f)

def save_attack_memory(memory):
    with open("logs/attacks_memory.json", "w") as f:
        json.dump(memory, f, indent=2)

def detect_intrusion():
    """Simule la détection d'activité réseau suspecte."""
    try:
        # Exemple simple : port scan ou brute force sur 22 (SSH)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.5)
        result = sock.connect_ex(("127.0.0.1", 22))
        sock.close()
        return result == 0  # True si port ouvert (possible brute force)
    except Exception as e:
        logger.error(f"Erreur détection réseau : {e}")
        return False

def analyze_and_record_attacker(ip, method="Brute Force SSH"):
    """Analyse l'attaque, la logue, et entraîne la mémoire IA."""
    attack_data = {
        "ip": ip,
        "method": method,
        "datetime": str(datetime.utcnow()),
        "hash": hashlib.sha256(f"{ip}{method}".encode()).hexdigest()
    }

    encrypted = fernet.encrypt(json.dumps(attack_data).encode()).decode()
    logger.warning(f"INTRUSION DÉTECTÉE ET ENCRYPTÉE : {encrypted}")

    memory = load_attack_memory()
    if attack_data["hash"] not in [entry["hash"] for entry in memory]:
        memory.append(attack_data)
        save_attack_memory(memory)

    # Placeholder pour géolocalisation IP
    logger.info(f"Emplacement géographique (simulation) pour {ip} : [À intégrer via IP-API]")

def secure_wallet_layer():
    """Double vérification du wallet"""
    try:
        secure_wallet_access()
        logger.info("Sécurisation du wallet réussie.")
    except Exception as e:
        logger.error(f"Échec sécurité wallet : {e}")

# Boucle de défense continue
def defense_loop():
    logger.info("HawkDefenseAI activé. Surveillance 24/24...")
    while True:
        if detect_intrusion():
            ip = "192.168.0.1"  # Simulation, à remplacer par scan réel
            analyze_and_record_attacker(ip)
            secure_wallet_layer()
        time.sleep(10)  # Surveillance toutes les 10 secondes

if __name__ == "__main__":
    try:
        defense_loop()
    except KeyboardInterrupt:
        logger.info("Arrêt manuel de HawkDefenseAI.")
