import os
import openai
import difflib
from pathlib import Path
from datetime import datetime

# Clé API OpenAI
openai.api_key = "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"  # Remplace ici avec ta vraie clé

# Journalisation
LOG_FILE = "repair_ai_logs.txt"

def log(msg: str):
    timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    with open(LOG_FILE, "a") as f:
        f.write(f"{timestamp} {msg}\n")
    print(f"{timestamp} {msg}")

def load_file_content(file_path: Path) -> str:
    with open(file_path, "r") as f:
        return f.read()

def save_file_content(file_path: Path, content: str):
    with open(file_path, "w") as f:
        f.write(content)

def ask_ai_to_repair(content: str, filename: str) -> str:
    prompt = f"""Tu es un expert en Python. Voici le contenu du fichier : {filename}.
Corrige les erreurs éventuelles, optimise le code, et améliore la structure.
Conserve les fonctionnalités existantes. Donne uniquement le nouveau code corrigé :

{content}
"""

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        return response["choices"][0]["message"]["content"].strip()
    except Exception as e:
        log(f"[Erreur AI] {e}")
        return None

def process_file(file_path: Path):
    try:
        log(f"Traitement du fichier : {file_path}")
        original = load_file_content(file_path)
        repaired = ask_ai_to_repair(original, file_path.name)
        if repaired:
            if repaired.strip() != original.strip():
                backup_path = file_path.with_suffix(".bak")
                save_file_content(backup_path, original)
                save_file_content(file_path, repaired)
                log(f"Réparé et sauvegardé : {file_path} (backup: {backup_path})")
            else:
                log(f"Aucune correction nécessaire: {file_path}")
        else:
            log(f"Aucune réponse AI pour : {file_path}")
    except Exception as e:
        log(f"[Erreur traitement fichier] {file_path} -> {e}")

def scan_folder(folder: Path):
    log(f"Démarrage du scan de : {folder}")
    for file in folder.rglob("*.py"):
        process_file(file)
    log("Scan terminé.")

if __name__ == "__main__":
    base_dir = Path(".")
    scan_folder(base_dir)

    # Propose une commande de migration (affichage uniquement)
    log(">> Pour migrer vers la dernière version OpenAI plus tard, exécute :")
    log(">> pip install --upgrade openai && openai migrate")
