import os
import json
import time
import logging
from datetime import datetime
from cryptography.fernet import Fernet

# Chemins des fichiers
KEY_PATH = "logs/wallet.key"
LOG_PATH = "logs/hawk_wallet_access.log"
DATA_FILE = "logs/wallet_data.json"

# Initialisation du logger
logger = logging.getLogger("hawk_wallet_manager")
logger.setLevel(logging.INFO)
if not os.path.exists("logs"):
    os.makedirs("logs")
fh = logging.FileHandler(LOG_PATH)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

# Génération ou chargement de la clé de cryptage
if not os.path.exists(KEY_PATH):
    with open(KEY_PATH, "wb") as f:
        f.write(Fernet.generate_key())

with open(KEY_PATH, "rb") as f:
    key = f.read()

fernet = Fernet(key)

# Initialisation des données sécurisées
if not os.path.exists(DATA_FILE):
    sample_data = {
        "private_key": fernet.encrypt(b"EXEMPLE_CLE_PRIVEE").decode(),
        "wallets": {"USD": 0.0, "EUR": 0.0},
        "last_update": datetime.utcnow().isoformat()
    }
    with open(DATA_FILE, "w") as f:
        json.dump(sample_data, f, indent=2)

# Système de défense neuronale activé en cas d'intrusion
def trigger_neural_defense(error_msg):
    logger.critical("Défense neuronale activée.")
    # Simulation d'alerte IA, future intégration possible : géoloc, IP, blocage
    with open("logs/intrusion_report.log", "a") as f:
        f.write(f"{datetime.utcnow().isoformat()} - ATTEMPT BLOCKED: {error_msg}\n")

def secure_wallet_access():
    try:
        with open(DATA_FILE, "r") as f:
            data = json.load(f)

        encrypted_key = data["private_key"]
        decrypted = fernet.decrypt(encrypted_key.encode()).decode()

        if decrypted != "EXEMPLE_CLE_PRIVEE":
            raise PermissionError("Clé corrompue.")

        logger.info("Accès sécurisé validé.")
        return decrypted

    except Exception as e:
        logger.error(f"Violation détectée : {e}")
        trigger_neural_defense(str(e))
        raise

class HawkWalletManager:
    def __init__(self):
        self.wallets = {"USD": 0.0, "EUR": 0.0}
        self.load_wallet()

    def load_wallet(self):
        try:
            with open(DATA_FILE, "r") as f:
                data = json.load(f)
                self.wallets = data.get("wallets", self.wallets)
        except Exception as e:
            logger.error(f"Erreur lors du chargement : {e}")
            self.save_wallet()

    def save_wallet(self):
        try:
            data = {
                "private_key": fernet.encrypt(b"EXEMPLE_CLE_PRIVEE").decode(),
                "wallets": self.wallets,
                "last_update": datetime.utcnow().isoformat()
            }
            with open(DATA_FILE, "w") as f:
                json.dump(data, f, indent=2)
            logger.info("Wallet sauvegardé avec succès.")
        except Exception as e:
            logger.error(f"Échec de sauvegarde du wallet : {e}")

    def update_wallet(self, currency, amount):
        if currency in self.wallets:
            self.wallets[currency] += amount
            self.save_wallet()
            logger.info(f"Wallet mis à jour : {currency} +{amount}")
        else:
            logger.warning(f"Devise non reconnue : {currency}")
