import sqlite3
import hashlib
import uuid
import time
import os

DB_PATH = "hawk_data.db"
TOKEN_EXPIRATION = 60 * 60 * 24 * 15  # 15 jours en secondes

class HawkUserManager:
    def __init__(self):
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                token TEXT,
                created_at INTEGER,
                status TEXT,
                blocked INTEGER DEFAULT 0,
                commission REAL DEFAULT 0.0
            )
        ''')
        conn.commit()
        conn.close()

    def _hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()

    def _generate_token(self):
        return uuid.uuid4().hex

    def create_user(self, username, password):
        if self.user_exists(username):
            return False
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        hashed = self._hash_password(password)
        now = int(time.time())
        token = self._generate_token()
        cursor.execute('''
            INSERT INTO users (username, password_hash, token, created_at, status)
            VALUES (?, ?, ?, ?, ?)
        ''', (username, hashed, token, now, "trial"))
        conn.commit()
        conn.close()
        return True

    def user_exists(self, username):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM users WHERE username = ?", (username,))
        exists = cursor.fetchone() is not None
        conn.close()
        return exists

    def authenticate_user(self, username, password):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        hashed = self._hash_password(password)
        cursor.execute('''
            SELECT token, blocked FROM users
            WHERE username = ? AND password_hash = ?
        ''', (username, hashed))
        result = cursor.fetchone()
        conn.close()
        if result:
            token, blocked = result
            return token if not blocked else None
        return None

    def validate_token(self, username, token):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT token, created_at, status, blocked FROM users
            WHERE username = ?
        ''', (username,))
        result = cursor.fetchone()
        conn.close()
        if result:
            saved_token, created_at, status, blocked = result
            if blocked:
                return False
            if token != saved_token:
                return False
            if status == "trial" and (time.time() - created_at) > TOKEN_EXPIRATION:
                return False
            return True
        return False

    def update_status(self):
        now = int(time.time())
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE users
            SET status = 'expired'
            WHERE status = 'trial' AND (? - created_at) > ?
        ''', (now, TOKEN_EXPIRATION))
        conn.commit()
        conn.close()

    def record_payment(self, username, commission):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE users
            SET status = 'paid', commission = commission + ?
            WHERE username = ?
        ''', (commission, username))
        conn.commit()
        conn.close()

    def get_user_info(self, username):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT username, status, commission, blocked
            FROM users WHERE username = ?
        ''', (username,))
        data = cursor.fetchone()
        conn.close()
        if data:
            return {
                "username": data[0],
                "status": data[1],
                "commission": data[2],
                "blocked": bool(data[3])
            }
        return None

    def block_user(self, username):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE users SET blocked = 1 WHERE username = ?
        ''', (username,))
        conn.commit()
        conn.close()

    def unblock_user(self, username):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE users SET blocked = 0 WHERE username = ?
        ''', (username,))
        conn.commit()
        conn.close()
