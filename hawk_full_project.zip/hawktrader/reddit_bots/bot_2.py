import praw

reddit = praw.Reddit(
    client_id="gpQjEt-OKyEylpWlRtrKwQl_2CoXcke2TgM2g2i_OG9RTtR528MfUNMwwsQ",
    client_secret="SECRET_FOR_BOT_2",
    user_agent="hawk_bot_2"
)

print("Reddit bot_2 prêt à poster.")
# Exemple de publication
# subreddit = reddit.subreddit("test")
# subreddit.submit("Titre test", selftext="Contenu HawkTrader")
