import praw

reddit = praw.Reddit(
    client_id="Redit",
    client_secret="SECRET_FOR_BOT_1",
    user_agent="hawk_bot_1"
)

print("Reddit bot_1 prêt à poster.")
# Exemple de publication
# subreddit = reddit.subreddit("test")
# subreddit.submit("Titre test", selftext="Contenu HawkTrader")
