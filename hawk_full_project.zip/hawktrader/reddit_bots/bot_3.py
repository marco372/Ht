import praw

reddit = praw.Reddit(
    client_id="k4flOYgJZwyUjcL-M41RHPBUNYugNQ",
    client_secret="SECRET_FOR_BOT_3",
    user_agent="hawk_bot_3"
)

print("Reddit bot_3 prêt à poster.")
# Exemple de publication
# subreddit = reddit.subreddit("test")
# subreddit.submit("Titre test", selftext="Contenu HawkTrader")
