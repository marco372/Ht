import requests
import json
from statistics import mean
from datetime import datetime
from hawk_logger import hawk_logger
from hawk_security import hash_sha256
from hawk_sentiment_analyzer import SentimentAnalyzer

# Ajout Défense AI
from defense_ai import monitor_event, alert_if_anomaly_detected

sentiment_engine = SentimentAnalyzer()  # initialisation séparée

class HawkAnalysisEngine:
    def __init__(self, crypto_list):
        self.crypto_list = crypto_list
        self.api_url = "https://api.coinpaprika.com/v1/tickers"
        self.data = {}

    def fetch_data(self):
        """Récupère les données de marché pour chaque cryptomonnaie."""
        try:
            response = requests.get(self.api_url)
            response.raise_for_status()
            all_data = response.json()

            monitor_event("ENGINE_DATA_RECEIVED", {
                "engine": "analysis_engine",
                "timestamp": datetime.utcnow().isoformat(),
                "source": "coinpaprika",
                "data_length": len(all_data)
            })

            for crypto in self.crypto_list:
                found = next((item for item in all_data if item["symbol"].upper() == crypto.upper()), None)
                if found:
                    self.data[crypto] = found
                else:
                    hawk_logger.warning(f"[fetch_data] Crypto {crypto} non trouvée.")
                    alert_if_anomaly_detected("DATA_MISSING", crypto)
        except Exception as e:
            hawk_logger.error(f"[fetch_data] Erreur lors de la récupération des données : {str(e)}")
            alert_if_anomaly_detected("ENGINE_ERROR", str(e))

    def analyze(self):
        """Effectue une analyse simple sur les cryptos sélectionnées."""
        result = {}
        for symbol, info in self.data.items():
            try:
                sentiment = sentiment_engine.get_average_sentiment(symbol)

                if sentiment > 0.3:
                    signal = "BUY"
                elif sentiment < -0.3:
                    signal = "SELL"
                else:
                    signal = "HOLD"

                quotes = info["quotes"]["USD"]
                price = quotes["price"]
                percent_change_1h = quotes["percent_change_1h"]
                percent_change_24h = quotes["percent_change_24h"]
                percent_change_7d = quotes["percent_change_7d"]

                monitor_event("SIGNAL_COMPUTED", {
                    "symbol": symbol,
                    "signal": signal,
                    "sentiment": sentiment,
                    "timestamp": datetime.utcnow().isoformat()
                })

                # Anomalie possible si variation anormale
                if abs(percent_change_1h) > 50 or abs(percent_change_24h) > 80:
                    alert_if_anomaly_detected("ABNORMAL_VARIATION", f"{symbol} {percent_change_1h}% / {percent_change_24h}%")

                result[symbol] = {
                    "price": price,
                    "change_1h": percent_change_1h,
                    "change_24h": percent_change_24h,
                    "change_7d": percent_change_7d,
                    "signal": signal,
                    "sentiment": sentiment
                }

            except Exception as e:
                hawk_logger.error(f"[analyze] Erreur avec {symbol} : {str(e)}")
                alert_if_anomaly_detected("ANALYZE_ERROR", str(e))

        return result
