import json
import logging
import time
from datetime import datetime
from binance.client import Client
from binance.exceptions import BinanceAPIException, BinanceOrderException

from hawk_strategy_ai import StrategyAI
from hawk_analysis_engine import HawkAnalysisEngine
from hawk_wallet_manager import secure_wallet_access
from defense_ai import monitor_event, alert_if_anomaly_detected

# === Initialisation des modules ===
strategy_ai = StrategyAI()
analysis_engine = HawkAnalysisEngine(["BTC", "ETH", "SOL", "BNB"])  # Exemple, à adapter selon config

# Chargement config
with open("hawk_config.json") as f:
    config = json.load(f)

with open("hawk_seuils.json") as f:
    seuils = json.load(f)

API_KEY = config["binance_api_key"]
API_SECRET = config["binance_api_secret"]
MAX_CRYPTOS = config.get("max_cryptos_traded", 2)
client = Client(API_KEY, API_SECRET)

# === Logger ===
logger = logging.getLogger("hawk_auto_trader")
logger.setLevel(logging.INFO)
fh = logging.FileHandler("logs/hawk_auto_trader.log")
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

# === Fonctions clés ===
def get_usdt_balance():
    try:
        balance = client.get_asset_balance(asset='USDT')
        return float(balance['free'])
    except Exception as e:
        logger.error(f"Erreur récupération balance USDT : {e}")
        return 0.0

def place_order(symbol, action, quantity):
    try:
        if action == "BUY":
            order = client.order_market_buy(symbol=symbol, quantity=quantity)
        elif action == "SELL":
            order = client.order_market_sell(symbol=symbol, quantity=quantity)
        else:
            raise ValueError("Action invalide")
        logger.info(f"Ordre {action} placé sur {symbol} : {order}")
        return order
    except (BinanceAPIException, BinanceOrderException) as e:
        logger.error(f"Erreur de trading : {e}")
        alert_if_anomaly_detected("BINANCE_ERROR", str(e))
        return None

# === Boucle principale ===
def run_trading_loop():
    while True:
        try:
            monitor_event("TRADING_LOOP_STARTED", {"time": datetime.utcnow().isoformat()})
            secure_wallet_access()  # Protection avant toute opération

            analysis_engine.fetch_data()
            analysis = analysis_engine.analyze()

            usdt_balance = get_usdt_balance()

            traded_count = 0
            for symbol, result in analysis.items():
                if traded_count >= MAX_CRYPTOS:
                    break

                signal = result["signal"]
                current_price = result["price"]
                quantity = round(usdt_balance / (MAX_CRYPTOS * current_price), 6)

                # Confirmation par IA stratégique
                final_decision = strategy_ai.confirm_decision(symbol, signal, result)
                logger.info(f"[{symbol}] Signal: {signal} | IA: {final_decision}")

                if final_decision == "BUY" and quantity > 0:
                    place_order(symbol + "USDT", "BUY", quantity)
                    traded_count += 1
                elif final_decision == "SELL":
                    # Vente simulée pour l’instant : prévoir suivi holdings
                    place_order(symbol + "USDT", "SELL", quantity)
                    traded_count += 1
                else:
                    logger.info(f"[{symbol}] Aucune action prise (signal: {final_decision})")

            monitor_event("TRADING_LOOP_ENDED", {"traded": traded_count})
            time.sleep(60)

        except Exception as e:
            logger.error(f"Erreur boucle trading : {str(e)}")
            alert_if_anomaly_detected("FATAL_TRADING_ERROR", str(e))
            time.sleep(30)
