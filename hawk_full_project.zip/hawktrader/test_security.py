from hawk_security import encrypt, decrypt, hash_sha256, sign_hmac, verify_hmac

# Test du chiffrement
message = "HawkTraderSecret123"
encrypted = encrypt(message)
decrypted = decrypt(encrypted)

print("[TEST CHIFFREMENT]")
print("Message original :", message)
print("Chiffré :", encrypted)
print("Déchiffré :", decrypted)
print("Résultat :", "OK" if message == decrypted else "ÉCHEC")

# Test du hachage
hashed = hash_sha256(message)
print("\n[TEST HACHAGE SHA-256]")
print("Haché :", hashed)

# Test du HMAC
key = "SuperSecretKey"
signature = sign_hmac(message, key)
is_valid = verify_hmac(message, key, signature)

print("\n[TEST HMAC-SHA256]")
print("Signature :", signature)
print("Validation :", "OK" if is_valid else "ÉCHEC")
