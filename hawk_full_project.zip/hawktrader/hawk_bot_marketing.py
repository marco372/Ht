Bot Marketing IA Ultra Performant pour HawkTrader

import os import random import time import requests from datetime import datetime from bs4 import BeautifulSoup from transformers import pipeline from telegram import Bot as TelegramBot from discord import Client as DiscordClient from praw import Reddit

=== CONFIGURATION GÉNÉRALE ===

TELEGRAM_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN" DISCORD_TOKEN = "YOUR_DISCORD_BOT_TOKEN" REDDIT_CLIENT_ID = "YOUR_REDDIT_CLIENT_ID" REDDIT_SECRET = "YOUR_REDDIT_SECRET" REDDIT_USER_AGENT = "hawk_marketing_bot" LANGUAGES = ["en", "fr", "ar"] KEYWORDS = ["crypto", "bitcoin", "ethereum", "trading", "altcoins"]

=== MODULE IA DE GÉNÉRATION DE PUB ===

text_gen = pipeline("text-generation", model="gpt2") translator = pipeline("translation", model="Helsinki-NLP/opus-mt-en-fr")

def generate_ad(keyword): prompt = f"Create a futuristic, powerful crypto trading ad for HawkTrader using keyword: {keyword}" result = text_gen(prompt, max_length=100, num_return_sequences=1)[0]['generated_text'] return result.strip()

def translate_ad(text, target_lang): if target_lang == "en": return text try: result = translator(text, tgt_lang=target_lang) return result[0]['translation_text'] except: return text

=== MODULE DE DIFFUSION TELEGRAM ===

class TelegramPoster: def init(self, token): self.bot = TelegramBot(token=token)

def send_message(self, chat_id, message):
    self.bot.send_message(chat_id=chat_id, text=message)

=== MODULE DE DIFFUSION DISCORD ===

class DiscordPoster(DiscordClient): async def on_ready(self): print(f"Discord bot connecté en tant que {self.user}") for guild in self.guilds: for channel in guild.text_channels: try: await channel.send(self.message) print(f"Message envoyé à {channel.name} dans {guild.name}") return except: continue

def post_message(self, message):
    self.message = message
    self.run(DISCORD_TOKEN)

=== MODULE DE POST REDDIT ===

class RedditPoster: def init(self): self.reddit = Reddit(client_id=REDDIT_CLIENT_ID, client_secret=REDDIT_SECRET, user_agent=REDDIT_USER_AGENT)

def post(self, subreddit_name, title, body):
    try:
        subreddit = self.reddit.subreddit(subreddit_name)
        subreddit.submit(title, selftext=body)
        print(f"Post Reddit envoyé dans r/{subreddit_name}")
    except Exception as e:
        print("Erreur Reddit:", e)

=== MODULE DE PLANIFICATION ET DIFFUSION ===

def run_campaign(): keyword = random.choice(KEYWORDS) ad = generate_ad(keyword)

for lang in LANGUAGES:
    translated = translate_ad(ad, lang)

    # Telegram
    tg = TelegramPoster(TELEGRAM_TOKEN)
    tg.send_message(chat_id="@YourChannelOrGroup", message=translated)

    # Discord
    dc = DiscordPoster()
    dc.post_message(message=translated)

    # Reddit
    rd = RedditPoster()
    rd.post(subreddit_name="CryptoMarketing", title="HawkTrader: The Future of Trading", body=translated)

    time.sleep(10)  # Pause entre chaque diffusion

if name == "main": print("[HawkTrader Marketing Bot] Lancement de la campagne...") run_campaign() print("[HawkTrader Marketing Bot] Campagne terminée.")
