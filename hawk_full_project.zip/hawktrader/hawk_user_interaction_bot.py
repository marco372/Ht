""" HawkTrader - Bot d'Interaction Utilisateur avec IA Fichier : hawk_user_interaction_bot.py Version : 2.0 Objectif : Interaction intelligente avec les utilisateurs via un modèle IA léger """

import json import time from datetime import datetime from transformers import pipeline from hawk_logger import log_event

Chargement du modèle de NLP

try: chatbot = pipeline("text-generation", model="tiiuae/falcon-7b-instruct") log_event("[INTERACTION BOT] Modèle Falcon-7B chargé avec succès.") except Exception as e: chatbot = None log_event(f"[INTERACTION BOT] Échec du chargement IA : {str(e)}")

Réponse via IA ou fallback manuel

DEFAULT_RESPONSES = { "bonjour": "Bonjour ! Comment puis-je vous aider aujourd’hui ?", "aide": "Voici ce que je peux faire pour vous : analyse, alerte, solde, transfert.", "solde": "Votre solde actuel est en cours de récupération...", "merci": "Avec plaisir ! Si vous avez besoin d’autre chose, je suis là.", "au revoir": "À bientôt ! Revenez quand vous voulez." }

def get_bot_response(message: str, user_id: str) -> str: message = message.lower().strip() log_event(f"[INTERACTION] {user_id} > {message}")

if chatbot:
    try:
        result = chatbot(message, max_length=60, do_sample=True, temperature=0.7)
        response = result[0]['generated_text'].strip()
        response = response.replace(message, '').strip()
        log_event(f"[INTERACTION][IA] Bot > {response}")
        return response
    except Exception as e:
        log_event(f"[INTERACTION][IA] Erreur : {str(e)}")

for key in DEFAULT_RESPONSES:
    if key in message:
        response = DEFAULT_RESPONSES[key]
        log_event(f"[INTERACTION][Fallback] Bot > {response}")
        return response

fallback = "Je n’ai pas compris votre demande. Tapez 'aide' pour voir mes capacités."
log_event(f"[INTERACTION][Fallback] Bot > {fallback}")
return fallback

Exemple de session

if name == "main": user_id = "user_demo" print("*** Bot d’Interaction Utilisateur - Session IA ***") while True: msg = input("Vous : ") if msg.lower() in ["exit", "quitter", "bye"]: print("Bot : À bientôt !") break print("Bot :", get_bot_response(msg, user_id))
