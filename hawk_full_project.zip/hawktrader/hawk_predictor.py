# === HawkTrader Predictor Complet ===
# Optimisation IA, gestion des risques, dry-run, explication, etc.
# ConformitÃ© Python 3.10+ (Termux compatible)

import os
import csv
import json
import joblib
import requests
import numpy as np
import pandas as pd
from datetime import datetime
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error
import shap
from hawk_logger import hawk_logger

# === CONSTANTES ===
DATA_FILE = "data/crypto_data.csv"
MODEL_DIR = "models/"
LOG_FILE = "logs/training_log.csv"
BEST_MODEL_FILE = "models/best_model.txt"
BEST_MODEL_SAVE = "models/best_model.joblib"
API_URL = "https://api.coinpaprika.com/v1/tickers/btc-bitcoin"
TRAINING_THRESHOLD = 100

# === CRÃ‰ATION DES DOSSIERS ===
os.makedirs("data", exist_ok=True)
os.makedirs("models", exist_ok=True)
os.makedirs("logs", exist_ok=True)

class HawkPredictor:
    def __init__(self):
        self.models = {
            "LinearRegression": LinearRegression(),
            "RandomForest": RandomForestRegressor(n_estimators=100),
            "SVR": SVR(),
            "GradientBoosting": GradientBoostingRegressor()
        }
        self.best_model_name = None
        self.best_model = None
        self.explainer = None
        self.risk_config = {
            "stop_loss": 0.05,      # -5%
            "take_profit": 0.10,    # +10%
            "trailing_stop": 0.03   # 3% trailing
        }
        self.load_best_model()

def collect_data(self):
    try:
        response = requests.get(API_URL)
        data = response.json()
        price = data["quotes"]["USD"]["price"]
        volume = data["quotes"]["USD"]["volume_24h"]
        timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

        with open(DATA_FILE, "a", newline="") as file:
            writer = csv.writer(file)
            if file.tell() == 0:
                writer.writerow(["timestamp", "price_usd", "volume_24h"])
            writer.writerow([timestamp, price, volume])
            hawk_logger.info(f"[Predictor] Donnée ajoutée : {timestamp}, {price}, {volume}")

        if self.should_train():
            self.auto_train_models()

    except Exception as e:
        hawk_logger.error(f"[Predictor] Erreur dans collect_data : {str(e)}")

def should_train(self):
    try:
        df = pd.read_csv(DATA_FILE)
        return len(df) >= TRAINING_THRESHOLD
    except:
        return False

    def auto_train_models(self):
        try:
            df = pd.read_csv(DATA_FILE)
            df["timestamp"] = pd.to_datetime(df["timestamp"])
            df["time_numeric"] = df["timestamp"].astype('int64') // 10**9

            X = df[["time_numeric", "volume_24h"]].values
            y = df["price_usd"].values

            performances = {}
            for name, model in self.models.items():
                model.fit(X, y)
                preds = model.predict(X)
                rmse = mean_squared_error(y, preds) ** 0.5
                performances[name] = rmse
                joblib.dump(model, os.path.join(MODEL_DIR, f"{name}.joblib"))

            self.best_model_name = min(performances, key=performances.get)
            self.best_model = joblib.load(os.path.join(MODEL_DIR, f"{self.best_model_name}.joblib"))
            with open(BEST_MODEL_FILE, "w") as f:
                f.write(self.best_model_name)
            joblib.dump(self.best_model, BEST_MODEL_SAVE)
            self.setup_explainer(X)
            self.log_training(datetime.utcnow(), performances)
hawk_logger.info(f"[Predictor] Meilleur modÃ¨le : {self.best_model_name} (RMSE={performances[self.best_model_name]:.4f})")
        except Exception as e:
            hawk_logger.error(f"[Predictor] Erreur dans auto_train_models : {str(e)}")

    def setup_explainer(self, X):
        try:
            if "tree" in self.best_model_name.lower():
                self.explainer = shap.Explainer(self.best_model, X)
            else:
                self.explainer = shap.Explainer(self.best_model.predict, X)
            hawk_logger.info("[Predictor] Explainer SHAP initialisÃ©.")
        except Exception as e:
            hawk_logger.warning(f"[Predictor] Impossible d'initialiser SHAP : {str(e)}")

    def log_training(self, date, performances):
        try:
            with open(LOG_FILE, "a", newline="") as file:
                writer = csv.writer(file)
                if file.tell() == 0:
                    writer.writerow(["timestamp"] + list(performances.keys()))
                writer.writerow([date.strftime("%Y-%m-%d %H:%M:%S")] + [f"{v:.4f}" for v in performances.values()])
        except Exception as e:
hawk_logger.error(f"[Predictor] Erreur dans log_training : {str(e)}")

    def predict(self, timestamp, volume, dry_run=False):
        try:
            if self.best_model is None:
                hawk_logger.warning("[Predictor] Aucun modÃ¨le n'est chargÃ©.")
                return None
            time_numeric = int(pd.to_datetime(timestamp).timestamp())
            features = np.array([[time_numeric, volume]])
            prediction = self.best_model.predict(features)[0]
            if dry_run:
                hawk_logger.info(f"[DryRun] PrÃ©diction (non exÃ©cutÃ©e) : {prediction}")
            else:
                hawk_logger.info(f"[Predictor] PrÃ©diction rÃ©elle : {prediction}")
            return prediction
        except Exception as e:
            hawk_logger.error(f"[Predictor] Erreur dans predict : {str(e)}")
            return None

    def apply_risk_management(self, buy_price, current_price):
        try:
            delta = (current_price - buy_price) / buy_price
            if delta <= -self.risk_config["stop_loss"]:
                return "Stop Loss ActivÃ©"
            elif delta >= self.risk_config["take_profit"]:
                return "Take Profit ActivÃ©"
            return "Position Maintenue"
        except Exception as e:
            hawk_logger.error(f"[Risk] Erreur de gestion de risque : {str(e)}")
            return "Erreur"

# === Tests & Validations Ã  ajouter dans un fichier test_hawk.py pour automatisation ===
# Exemple : pytest ou unittest pour les fonctions de prÃ©diction, d'entraÃ®nement, etc.
