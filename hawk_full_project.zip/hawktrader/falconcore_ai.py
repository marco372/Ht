import os import importlib import logging

Initialisation du logger FalconCore

logging.basicConfig(level=logging.INFO) logger = logging.getLogger("FalconCoreAI")

Modules clés HawkTrader à connecter automatiquement

CORE_MODULES = [ "hawk_manager", "hawk_defence_ai", "hawk_security", "hawk_alert_manager", "hawk_user_manager", "hawk_wallet_manager", "hawk_predictor", "hawk_predictor_complet", "hawk_strategy_ai", "hawk_sentiment_analyzer", "repair_ai", "linker_ai", "hawk_bot_marketing", "hawk_user_interaction_bot" ]

BOT_FOLDERS = ["telegram_bots", "reddit_bots"]

def charger_module(nom): try: mod = importlib.import_module(nom) logger.info(f"Module chargé : {nom}") return mod except Exception as e: logger.warning(f"Erreur de chargement {nom} : {e}") return None

def scanner_et_analyser(): logger.info("Scan global de HawkTrader en cours...") fichiers = os.listdir(".") for fichier in fichiers: if fichier.endswith(".py") and not fichier.startswith("falconcore"): if "test_" not in fichier and "install" not in fichier: try: modname = fichier[:-3] module = charger_module(modname) if module: logger.info(f"Analyse IA : {modname}") if hasattr(module, "analyse_falcon"): module.analyse_falcon() except Exception as e: logger.warning(f"Erreur analyse {fichier} : {e}")

def connecter_bots(): for dossier in BOT_FOLDERS: chemin = os.path.join("./", dossier) if os.path.isdir(chemin): for script in os.listdir(chemin): if script.endswith(".py"): nom_complet = f"{dossier}.{script[:-3]}" charger_module(nom_complet)

def initialiser_falconcore(): logger.info("Initialisation FalconCoreAI vMax en cours...") for mod in CORE_MODULES: charger_module(mod) connecter_bots() scanner_et_analyser() logger.info("FalconCoreAI prêt. Surveillance active.")

if name == "main": initialiser_falconcore()
