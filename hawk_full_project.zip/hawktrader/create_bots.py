import os

def create_folder(path):
    if not os.path.exists(path):
        os.makedirs(path)

def save_token(platform, bot_name, token):
    token_file = f"tokens/{platform}_tokens.txt"
    with open(token_file, "a") as f:
        f.write(f"{bot_name},{token}\n")

def create_bot_file(platform, bot_number, token):
    folder = f"{platform}_bots"
    filename = f"{folder}/bot_{bot_number}.py"
    
    if platform == "telegram":
        content = f"""import telebot

bot = telebot.TeleBot("{token}")

@bot.message_handler(commands=['start'])
def start(msg):
    bot.reply_to(msg, "Bonjour, je suis bot_{bot_number} HawkTrader Telegram!")

print("Telegram bot_{bot_number} lancé...")
bot.polling()
"""
    elif platform == "reddit":
        content = f"""import praw

reddit = praw.Reddit(
    client_id="{token}",
    client_secret="SECRET_FOR_BOT_{bot_number}",
    user_agent="hawk_bot_{bot_number}"
)

print("Reddit bot_{bot_number} prêt à poster.")
# Exemple de publication
# subreddit = reddit.subreddit("test")
# subreddit.submit("Titre test", selftext="Contenu HawkTrader")
"""
    elif platform == "discord":
        content = f"""import discord

TOKEN = "{token}"
intents = discord.Intents.default()
client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print("Discord bot_{bot_number} connecté.")

client.run(TOKEN)
"""
    else:
        print("Plateforme inconnue.")
        return

    with open(filename, "w") as f:
        f.write(content)

def main():
    print("=== Création de Bots HawkTrader ===")
    print("Plateformes disponibles : telegram / reddit / discord")
    platform = input("Choisir une plateforme : ").strip().lower()
    
    if platform not in ["telegram", "reddit", "discord"]:
        print("Plateforme non reconnue.")
        return

    try:
        count = int(input("Combien de bots veux-tu créer ? (ex: 50) : "))
    except ValueError:
        print("Entrée invalide.")
        return

    # Créer les dossiers si nécessaires
    create_folder(f"{platform}_bots")
    create_folder("tokens")

    for i in range(1, count + 1):
        bot_name = f"bot_{i}"
        token = input(f"Entrer le TOKEN de {bot_name} ({platform}) : ").strip()
        create_bot_file(platform, i, token)
        save_token(platform, bot_name, token)
        print(f"[OK] {bot_name} créé avec succès.")

    print(f"\nTous les {count} bots {platform} ont été créés avec succès !")

if __name__ == "__main__":
    main()

