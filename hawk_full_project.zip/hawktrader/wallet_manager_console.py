import logging from hawk_wallet_manager import HawkWalletManager

Set up logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

Initialize the wallet manager

wallet = HawkWalletManager()

def show_balances(): usd = wallet.get_solde("USD") eur = wallet.get_solde("EUR") print(f"Wallet Balances: {usd} USD | {eur} EUR")

def simulate_transfer(amount: float, currency: str): if wallet.remove_gain(currency, amount): print(f"[SUCCESS] {amount} {currency} successfully transferred.") show_balances() else: print(f"[FAILED] Not enough funds to transfer {amount} {currency}.")

if name == "main": print("Welcome to HawkTrader Wallet Console") show_balances()

while True:
    print("\nOptions:")
    print("1 - Show Wallet Balances")
    print("2 - Simulate Transfer")
    print("3 - Exit")

    choice = input("Choose an option: ")

    if choice == "1":
        show_balances()
    elif choice == "2":
        currency = input("Enter currency (USD/EUR): ").upper()
        try:
            amount = float(input("Enter amount to transfer: "))
            simulate_transfer(amount, currency)
        except ValueError:
            print("Invalid amount.")
    elif choice == "3":
        print("Goodbye!")
        break
    else:
        print("Invalid choice.")
