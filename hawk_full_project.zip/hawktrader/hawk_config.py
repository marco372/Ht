# hawk_config.py

import json
import os
import threading
from typing import Any, Dict

CONFIG_FILE = "hawk_config.json"
_lock = threading.Lock()
_cached_config: Dict[str, Any] = {}

# Configuration par défaut
_default_config = {
    "api_keys": {
        "coinpaprika": "YOUR_API_KEY_HERE",
        "newsapi": "YOUR_NEWS_API_KEY_HERE"
    },
    "thresholds": {
        "buy_signal": 0.75,
        "sell_signal": -0.75
    },
    "preferences": {
        "language": "en",  # Options: "en", "fr", "ar"
        "mode": "demo",    # Options: "demo", "live"
        "currency": "USD"
    }
}


def _deep_merge(default: dict, override: dict) -> dict:
    """Mélange récursivement la configuration par défaut avec celle de l'utilisateur."""
    result = default.copy()
    for key, value in override.items():
        if isinstance(value, dict) and key in result:
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _validate_config(config: dict) -> bool:
    """Valide les clés critiques pour éviter les erreurs runtime."""
    try:
        assert isinstance(config["api_keys"]["coinpaprika"], str)
        assert isinstance(config["thresholds"]["buy_signal"], float)
        assert config["preferences"]["mode"] in ["demo", "live"]
        return True
    except (KeyError, AssertionError):
        return False


def load_config() -> dict:
    """Charge la configuration, utilise le cache si dispo."""
    global _cached_config
    with _lock:
        if _cached_config:
            return _cached_config

        if not os.path.exists(CONFIG_FILE):
            save_config(_default_config)
            _cached_config = _default_config
            return _cached_config

        try:
            with open(CONFIG_FILE, 'r') as f:
                user_config = json.load(f)
            merged = _deep_merge(_default_config, user_config)
            if not _validate_config(merged):
                raise ValueError("Config invalide détectée. Valeurs par défaut restaurées.")
            _cached_config = merged
            return _cached_config
        except Exception as e:
            print(f"[hawk_config][ERROR] {e}")
            save_config(_default_config)
            _cached_config = _default_config
            return _cached_config


def save_config(config: dict) -> None:
    """Enregistre la configuration dans un fichier JSON."""
    with _lock:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)


def update_config(key_path: str, value: Any) -> None:
    """Met à jour dynamiquement une valeur dans la config via un chemin 'clé1.clé2'."""
    keys = key_path.split('.')
    config = load_config()
    d = config
    for key in keys[:-1]:
        d = d.setdefault(key, {})
    d[keys[-1]] = value
    save_config(config)
    _cached_config.clear()  # Reset le cache


# Exécution de test
if __name__ == "__main__":
    cfg = load_config()
    print("[CONFIG ACTUELLE]", json.dumps(cfg, indent=4))

    # Exemple de mise à jour
    update_config("preferences.language", "fr")
