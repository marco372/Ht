import json
import datetime
from textblob import TextBlob
import os

SENTIMENT_LOG_PATH = "sentiment_history.json"
LEARNING_LOG_PATH = "strategy_learning.json"

class SentimentAnalyzer:
    def __init__(self):
        self.sentiment_memory = self.load_sentiment_history()
        self.learning_memory = self.load_learning_history()

    def load_sentiment_history(self):
        if os.path.exists(SENTIMENT_LOG_PATH):
            with open(SENTIMENT_LOG_PATH, "r") as f:
                return json.load(f)
        return []

    def load_learning_history(self):
        if os.path.exists(LEARNING_LOG_PATH):
            with open(LEARNING_LOG_PATH, "r") as f:
                return json.load(f)
        return {}

    def save_state(self):
        with open(SENTIMENT_LOG_PATH, "w") as f:
            json.dump(self.sentiment_memory, f, indent=2)

        with open(LEARNING_LOG_PATH, "w") as f:
            json.dump(self.learning_memory, f, indent=2)

    def analyze_text(self, text: str) -> float:
        """Analyse une phrase et retourne un score entre -1 et +1"""
        blob = TextBlob(text)
        return blob.sentiment.polarity

    def update_sentiment(self, coin: str, text: str):
        score = self.analyze_text(text)
        record = {
            "coin": coin.upper(),
            "score": score,
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "text": text
        }
        self.sentiment_memory.append(record)
        self.save_state()
        return score

    def get_average_sentiment(self, coin: str, limit: int = 10):
        records = [r for r in self.sentiment_memory if r["coin"] == coin.upper()]
        if len(records) == 0:
            return 0.0
        scores = [r["score"] for r in records[-limit:]]
        return sum(scores) / len(scores)

    def register_trade_result(self, coin: str, strategy_name: str, profit: float):
        """Enregistre le résultat d’une stratégie pour apprentissage futur"""
        key = f"{coin.upper()}::{strategy_name}"
        if key not in self.learning_memory:
            self.learning_memory[key] = {"success": 0, "fail": 0, "total_profit": 0.0}

        self.learning_memory[key]["total_profit"] += profit
        if profit >= 0:
            self.learning_memory[key]["success"] += 1
        else:
            self.learning_memory[key]["fail"] += 1

        self.save_state()

    def get_strategy_rating(self, coin: str, strategy_name: str):
        key = f"{coin.upper()}::{strategy_name}"
        if key not in self.learning_memory:
            return {"rating": 0.0, "total_uses": 0}
        data = self.learning_memory[key]
        total = data["success"] + data["fail"]
        rating = (data["success"] / total) if total > 0 else 0.0
        return {"rating": rating, "total_uses": total}
