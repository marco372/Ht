import sys import os from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QVBoxLayout, QGraphicsOpacityEffect from PyQt5.QtGui import QPixmap, QFont, QPalette, QBrush, QColor from PyQt5.QtCore import Qt, QTimer, QPropertyAnimation from PyQt5.QtMultimedia import QSound

class HawkIntro(QWidget): def init(self, on_finished): super().init() self.on_finished = on_finished self.setWindowTitle("HawkTrader Intro") self.setGeometry(100, 100, 1024, 600) self.setStyleSheet("background-color: black;")

layout = QVBoxLayout()
    self.label_title = QLabel("HawkTrader – L’intelligence de demain")
    self.label_sub = QLabel("Système d’analyse crypto le plus puissant au monde")
    self.label_author = QLabel("Créé par M.M.Z.A")

    for label in (self.label_title, self.label_sub, self.label_author):
        label.setStyleSheet("color: white;")
        label.setAlignment(Qt.AlignCenter)
    self.label_title.setFont(QFont("Orbitron", 22, QFont.Bold))
    self.label_sub.setFont(QFont("Orbitron", 16))
    self.label_author.setFont(QFont("Orbitron", 12))

    layout.addStretch()
    layout.addWidget(self.label_title)
    layout.addWidget(self.label_sub)
    layout.addWidget(self.label_author)
    layout.addStretch()

    self.setLayout(layout)
    QTimer.singleShot(4000, self.end_intro)

def end_intro(self):
    self.on_finished()
    self.close()

class HawkUIDashboard(QWidget): def init(self): super().init() self.setWindowTitle("HawkTrader Dashboard") self.setGeometry(100, 100, 1024, 600) self.init_ui()

def init_ui(self):
    # Background
    if os.path.exists("background.jpg"):
        self.setAutoFillBackground(True)
        palette = QPalette()
        pixmap = QPixmap("background.jpg").scaled(self.size(), Qt.KeepAspectRatioByExpanding)
        palette.setBrush(QPalette.Window, QBrush(pixmap))
        self.setPalette(palette)

    # Sound piano
    if os.path.exists("intro_piano.wav"):
        QSound.play("intro_piano.wav")

    layout = QVBoxLayout()
    self.setLayout(layout)

    btn1 = self.create_button("Analyse Marché")
    btn2 = self.create_button("Voir Logs")
    btn3 = self.create_button("Configuration")

    layout.addStretch()
    layout.addWidget(btn1, alignment=Qt.AlignCenter)
    layout.addWidget(btn2, alignment=Qt.AlignCenter)
    layout.addWidget(btn3, alignment=Qt.AlignCenter)
    layout.addStretch()

def create_button(self, text):
    button = QPushButton(text)
    button.setFont(QFont("Orbitron", 12))
    button.setStyleSheet("""
        QPushButton {
            background-color: #0d0d0d;
            color: #00ffe1;
            border: 2px solid #00ffe1;
            border-radius: 10px;
            padding: 10px;
        }
        QPushButton:hover {
            background-color: #1a1a1a;
            color: #ffffff;
        }
        QPushButton:pressed {
            background-color: #33ffcc;
            color: #000000;
        }
    """)
    return button

Lancement

if name == 'main': app = QApplication(sys.argv)

def show_dashboard():
    dashboard = HawkUIDashboard()
    dashboard.show()
    sys.exit(app.exec_())

intro = HawkIntro(show_dashboard)
intro.show()
sys.exit(app.exec_())
