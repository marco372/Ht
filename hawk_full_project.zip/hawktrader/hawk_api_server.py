from flask import Flask, request, jsonify
from hawk_user_manager import HawkUserManager
from hawk_analysis_engine import HawkAnalysisEngine
from defense_ai import monitor_event, alert_if_anomaly_detected
import traceback
import time

app = Flask(__name__)
user_manager = HawkUserManager()

# === Routes ===

@app.route("/register", methods=["POST"])
def register():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    
    if not username or not password:
        monitor_event("REGISTER_FAIL", {"ip": request.remote_addr, "reason": "missing_fields"})
        return jsonify({"error": "Champs manquants"}), 400

    if user_manager.create_user(username, password):
        monitor_event("REGISTER_SUCCESS", {"user": username})
        return jsonify({"message": "Utilisateur créé avec succès"}), 201

    monitor_event("REGISTER_FAIL", {"user": username, "reason": "user_exists"})
    return jsonify({"error": "Nom d'utilisateur déjà existant"}), 409

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")

    token = user_manager.authenticate_user(username, password)
    if token:
        monitor_event("LOGIN_SUCCESS", {"user": username})
        return jsonify({"token": token}), 200

    alert_if_anomaly_detected("LOGIN_FAIL", f"Tentative échouée : {username}")
    return jsonify({"error": "Connexion refusée"}), 401

@app.route("/status", methods=["POST"])
def status():
    data = request.get_json()
    username = data.get("username")
    token = data.get("token")

    if user_manager.validate_token(username, token):
        info = user_manager.get_user_info(username)
        monitor_event("STATUS_CHECK", {"user": username})
        return jsonify(info), 200

    alert_if_anomaly_detected("INVALID_TOKEN", f"Status access refusé pour {username}")
    return jsonify({"error": "Token invalide ou expiré"}), 403

@app.route("/pay", methods=["POST"])
def pay():
    data = request.get_json()
    username = data.get("username")
    token = data.get("token")
    amount = float(data.get("commission", 0))

    if not user_manager.validate_token(username, token):
        alert_if_anomaly_detected("INVALID_TOKEN", f"Paiement refusé pour {username}")
        return jsonify({"error": "Token invalide ou expiré"}), 403

    user_manager.record_payment(username, amount)
    monitor_event("PAYMENT_RECORDED", {"user": username, "amount": amount})
    return jsonify({"message": f"{amount}$ enregistré pour {username}"}), 200

@app.route("/analyze", methods=["POST"])
def analyze():
    try:
        data = request.get_json()
        username = data.get("username")
        token = data.get("token")
        symbol = data.get("symbol", "BTC").upper()

        if not user_manager.validate_token(username, token):
            alert_if_anomaly_detected("INVALID_TOKEN", f"Analyse refusée pour {username}")
            return jsonify({"error": "Token invalide ou expiré"}), 403

        engine = HawkAnalysisEngine([symbol])
        engine.fetch_data()
        result = engine.analyze()

        monitor_event("ANALYZE_REQUEST", {"user": username, "symbol": symbol})
        return jsonify({symbol: result.get(symbol, "Aucune donnée trouvée")}), 200

    except Exception as e:
        traceback.print_exc()
        alert_if_anomaly_detected("ANALYZE_ERROR", str(e))
        return jsonify({"error": "Erreur lors de l'analyse"}), 500

# === Lancement serveur ===
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
