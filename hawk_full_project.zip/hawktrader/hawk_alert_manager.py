import json
import datetime

# Charger les seuils dynamiquement
def charger_seuils():
    try:
        with open("hawk_seuils.json", "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def verifier_seuil(nom, prix_actuel):
    SEUILS = charger_seuils()
    if nom not in SEUILS:
        return None

    min_seuil = SEUILS[nom]["min"]
    max_seuil = SEUILS[nom]["max"]

    if prix_actuel < min_seuil:
        log_event(f"{nom} est passé en-dessous de {min_seuil} USD. Prix actuel : {prix_actuel}")
        return "bas"
    elif prix_actuel > max_seuil:
        log_event(f"{nom} a dépassé {max_seuil} USD. Prix actuel : {prix_actuel}")
        return "haut"
    else:
        return "ok"

def log_event(message):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ligne = f"[{now}] {message}"
    print(ligne)
    with open("hawk_logs.txt", "a") as f:
        f.write(ligne + "\n")
