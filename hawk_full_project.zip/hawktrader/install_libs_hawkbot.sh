#!/data/data/com.termux/files/usr/bin/bash

# Liste des bibliothèques avec leur taille estimée (Mo)
libs=(
  "schedule:10"
  "aiohttp:20"
  "twython:25"
  "openai:30"
  "telethon:50"
  "discord.py:60"
  "selenium:100"
)

echo "==== DÉBUT DE L’INSTALLATION AUTOMATIQUE ===="
free_space=$(df /data | awk 'NR==2 {print $4}')
free_space_mb=$((free_space / 1024))
echo "Espace disponible : $free_space_mb Mo"
echo "---------------------------------------"

for entry in "${libs[@]}"; do
  lib=$(echo "$entry" | cut -d':' -f1)
  size=$(echo "$entry" | cut -d':' -f2)

  echo "[*] Installation de $lib (≈ ${size}Mo)..."

  if [ "$free_space_mb" -lt "$size" ]; then
    echo "    - Ignoré : espace insuffisant pour $lib"
    continue
  fi

  pip install "$lib"
  echo "    - $lib installé avec succès."
  echo "---------------------------------------"
done

echo "==== INSTALLATION TERMINÉE ===="
