import os
import openai
from pathlib import Path
from datetime import datetime

# Clé API OpenAI
openai.api_key = "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 "

LOG_FILE = "linker_ai_logs.txt"

def log(msg: str):
    timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    with open(LOG_FILE, "a") as f:
        f.write(f"{timestamp} {msg}\n")
    print(f"{timestamp} {msg}")

def load_file(file_path: Path) -> str:
    with open(file_path, "r") as f:
        return f.read()

def ask_ai_to_link(file1_name: str, file2_name: str, content1: str, content2: str) -> str:
    prompt = f"""
Tu es un expert en architecture logicielle Python.

Voici deux fichiers du projet HawkTrader :
1. {file1_name}
2. {file2_name}

Analyse leur contenu et dis s'il y a :
- des connexions manquantes (imports, appels de fonctions, dépendances)
- des redondances inutiles
- des optimisations possibles pour mieux les relier

Réponds uniquement par des suggestions concrètes d'amélioration ou indique "Aucune suggestion".
    
Contenu de {file1_name} :
{content1}

Contenu de {file2_name} :
{content2}
"""

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        return response["choices"][0]["message"]["content"].strip()
    except Exception as e:
        log(f"[Erreur AI] {e}")
        return None

def process_link(file1: Path, file2: Path):
    try:
        log(f"Comparaison entre {file1.name} et {file2.name}")
        content1 = load_file(file1)
        content2 = load_file(file2)
        suggestion = ask_ai_to_link(file1.name, file2.name, content1, content2)
        if suggestion:
            if "Aucune suggestion" in suggestion:
                log(f"Aucune suggestion pour: {file1.name} <-> {file2.name}")
            else:
                log(f"SUGGESTIONS ({file1.name} <-> {file2.name}):\n{suggestion}")
        else:
            log(f"Erreur AI pour la paire : {file1.name} et {file2.name}")
    except Exception as e:
        log(f"[Erreur traitement lien] {file1} <-> {file2} -> {e}")

def linker_scan(folder: Path):
    log(f"Scan des fichiers pour liens croisés dans : {folder}")
    py_files = sorted(list(folder.rglob("*.py")))
    for i in range(len(py_files)):
        for j in range(i + 1, len(py_files)):
            process_link(py_files[i], py_files[j])
    log("Lien AI terminé.")

if __name__ == "__main__":
    base_dir = Path(".")
    linker_scan(base_dir)

    # Propose une commande de migration pour plus tard
    log(">> Pour migrer vers la nouvelle version de l’API :")
    log(">> pip install --upgrade openai && openai migrate")
