import requests
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import json

# Fonction d'envoi d'alerte par email
def envoyer_alerte(nom_crypto, prix, seuil_max, seuil_min):
    from_email = "ton_email@example.com"
    to_email = "destinataire@example.com"
    password = "ton_mot_de_passe"
    
    subject = f"Alerte Crypto : {nom_crypto}"
    body = f"La crypto {nom_crypto} a atteint un prix de {prix}.\n\nSeuil Max: {seuil_max}\nSeuil Min: {seuil_min}"

    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    # Envoi de l'email via SMTP
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login("abdoustar1001@gmail.com", "abdou1995")
    text = msg.as_string()
    server.sendmail("abdoustar1001@gmail.com","abdoustar1001@gmail.com", text)
    server.quit()

# Fonction de récupération des données
def recuperer_donnees_crypto():
    url = "https://api.coinpaprika.com/v1/tickers"
    response = requests.get(url)
    return response.json()

# Fonction principale du bot
def analyse_crypto():
    seuils = {}
    try:
        with open("hawk_seuils.json", "r") as f:
            seuils = json.load(f)
    except:
        print("Erreur lors de la lecture des seuils.")

    cryptos = recuperer_donnees_crypto()

    for crypto in cryptos:
        if crypto["symbol"] in seuils:
            nom = crypto["name"]
            prix = crypto["quotes"]["USD"]["price"]
            seuil_max = seuils[crypto["symbol"]]["max"]
            seuil_min = seuils[crypto["symbol"]]["min"]

            if prix >= seuil_max or prix <= seuil_min:
                envoyer_alerte(nom, prix, seuil_max, seuil_min)

# Appeler la fonction pour démarrer l'analyse
if __name__ == "__main__":
    analyse_crypto()
