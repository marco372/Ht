from hawk_logger import log_info, log_warning, log_error, log_debug

log_info("Test INFO : tout fonctionne correctement.")
log_warning("Test WARNING : attention à quelque chose.")
log_error("Test ERROR : une erreur est survenue.")
log_debug("Test DEBUG : détails pour débogage.")
