import hashlib
import hmac
import base64
from cryptography.fernet import Fernet
import os

# Génère et stocke une clé Fernet (AES) si elle n'existe pas
KEY_PATH = "hawk.key"
if not os.path.exists(KEY_PATH):
    with open(KEY_PATH, "wb") as f:
        f.write(Fernet.generate_key())

with open(KEY_PATH, "rb") as f:
    SECRET_KEY = f.read()

fernet = Fernet(SECRET_KEY)

# Chiffrement / Déchiffrement de données sensibles
def encrypt(data: str) -> str:
    return fernet.encrypt(data.encode()).decode()

def decrypt(token: str) -> str:
    return fernet.decrypt(token.encode()).decode()

# Hachage SHA-256 (utile pour stocker des mots de passe ou ID)
def hash_sha256(data: str) -> str:
    return hashlib.sha256(data.encode()).hexdigest()

# Vérification HMAC-SHA256 (intégrité + signature)
def verify_hmac(data: str, key: str, signature: str) -> bool:
    computed = hmac.new(key.encode(), data.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(computed, signature)

# Signature HMAC-SHA256
def sign_hmac(data: str, key: str) -> str:
    return hmac.new(key.encode(), data.encode(), hashlib.sha256).hexdigest()
