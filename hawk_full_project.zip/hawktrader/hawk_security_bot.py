# HawkTrader - Bot de Sécurité Avancé
# Fichier : hawk_securite_bot.py
# Version : 1.0
# Objectif : Protection de la plateforme par tokenisation, journalisation et surveillance

import jwt
import time
import threading
import hashlib
import logging
import sqlite3
from datetime import datetime, timedelta

# Clé secrète pour JWT (à sécuriser en production)
SECRET_KEY = "UltraSecretKeyChangeThis"

# Connexion à la base de données
conn = sqlite3.connect("hawk_data.db", check_same_thread=False)
cursor = conn.cursor()

# Table des logs de sécurité
cursor.execute('''
CREATE TABLE IF NOT EXISTS security_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event TEXT NOT NULL,
    ip TEXT DEFAULT 'unknown',
    timestamp TEXT NOT NULL
)
''')
conn.commit()

def generate_token(user_id):
    """Génère un token JWT valable 1h"""
    payload = {
        'user_id': user_id,
        'exp': datetime.utcnow() + timedelta(hours=1)
    }
    token = jwt.encode(payload, SECRET_KEY, algorithm='HS256')
    return token

def verify_token(token):
    """Vérifie un token JWT et retourne les données utilisateur"""
    try:
        decoded = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        return decoded
    except jwt.ExpiredSignatureError:
        log_security_event("Token expiré")
        return None
    except jwt.InvalidTokenError:
        log_security_event("Token invalide")
        return None

def log_security_event(event, ip="unknown"):
    """Enregistre un événement de sécurité dans la base"""
    timestamp = datetime.utcnow().isoformat()
    cursor.execute("INSERT INTO security_logs (event, ip, timestamp) VALUES (?, ?, ?)", (event, ip, timestamp))
    conn.commit()
    print(f"[SECURITY] {event} | IP: {ip} | {timestamp}")

def monitor_login_activity():
    """Surveillance fictive (à améliorer avec IP réelle et heuristique)"""
    while True:
        # Simulation : log de test
        log_security_event("Surveillance active")
        time.sleep(3600)

def hash_sensitive_data(data):
    """Hash SHA-256 pour les données sensibles"""
    return hashlib.sha256(data.encode()).hexdigest()

# Thread de surveillance en arrière-plan
security_thread = threading.Thread(target=monitor_login_activity, daemon=True)
security_thread.start()

if __name__ == "__main__":
    print("[SECURITY BOT] Démarré avec succès.")
    test_token = generate_token("user123")
    print("Token de test :")
    print(test_token)
    decoded = verify_token(test_token)
    print("Données décodées :", decoded)
