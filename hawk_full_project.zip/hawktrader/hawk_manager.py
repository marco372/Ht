import sqlite3
import hashlib
import secrets
import datetime
import logging
from typing import Optional, Tuple, Dict
from hawk_wallet_manager import HawkwalletManager
wallet= HawkWalletManager()
wallet_manager.initialiser_wallet()
DB_PATH = 'hawk_data.db'
TOKEN_EXPIRY_DAYS = 30
TRIAL_DURATION_DAYS = 15

logging.basicConfig(
    filename="logs/hawk_user_manager.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)


class HawkUserManager:
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._create_users_table()

    def _create_users_table(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    token TEXT,
                    token_expiry DATETIME,
                    trial_start DATETIME,
                    status TEXT DEFAULT 'trial',  -- trial, active, expired, blocked
                    last_payment DATETIME,
                    total_commission REAL DEFAULT 0.0
                );
            """)
            conn.commit()

    def _hash_password(self, password: str) -> str:
        return hashlib.sha256(password.encode()).hexdigest()

    def _generate_token(self) -> str:
        return secrets.token_hex(32)

    def create_user(self, username: str, password: str) -> bool:
        password_hash = self._hash_password(password)
        trial_start = datetime.datetime.utcnow()
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO users (username, password_hash, trial_start, token, token_expiry)
                    VALUES (?, ?, ?, ?, ?);
                """, (
                    username,
                    password_hash,
                    trial_start,
                    self._generate_token(),
                    trial_start + datetime.timedelta(days=TOKEN_EXPIRY_DAYS)
                ))
                conn.commit()
            logging.info(f"New user created: {username}")
            return True
        except sqlite3.IntegrityError:
            logging.warning(f"User creation failed: {username} already exists.")
            return False

    def authenticate_user(self, username: str, password: str) -> Optional[str]:
        password_hash = self._hash_password(password)
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, password_hash, status FROM users WHERE username = ?;
            """, (username,))
            row = cursor.fetchone()
            if row and row[1] == password_hash:
                if row[2] == "blocked":
                    logging.warning(f"Blocked user tried to login: {username}")
                    return None
                token = self._generate_token()
                token_expiry = datetime.datetime.utcnow() + datetime.timedelta(days=TOKEN_EXPIRY_DAYS)
                cursor.execute("""
                    UPDATE users SET token = ?, token_expiry = ? WHERE username = ?;
                """, (token, token_expiry, username))
                conn.commit()
                logging.info(f"User authenticated: {username}")
                return token
        logging.warning(f"Authentication failed for: {username}")
        return None

    def validate_token(self, username: str, token: str) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT token, token_expiry FROM users WHERE username = ?;
            """, (username,))
            row = cursor.fetchone()
            if row and row[0] == token:
                expiry = datetime.datetime.fromisoformat(row[1])
                if datetime.datetime.utcnow() <= expiry:
                    return True
        return False

    def update_status(self):
        """Update user status based on trial expiration."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT username, trial_start, status FROM users;
            """)
            users = cursor.fetchall()
            for username, trial_start, status in users:
                trial_start_date = datetime.datetime.fromisoformat(trial_start)
                if status == "trial" and (datetime.datetime.utcnow() - trial_start_date).days > TRIAL_DURATION_DAYS:
                    cursor.execute("""
                        UPDATE users SET status = 'expired' WHERE username = ?;
                    """, (username,))
                    logging.info(f"Trial expired for user: {username}")
            conn.commit()

def record_payment(self, username: str, commission: float):
    """Record a payment and reset user status to active."""
    with sqlite3.connect(self.db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE users SET status = 'active' WHERE username = ?;
        """, (username,))
        conn.commit()
        logging.info(f"Payment recorded and status reset for user: {username}")

    # Appel de la fonction pour enregistrer le gain
    self.enregistrer_gain(commission, "USD")

def enregistrer_gain(self, montant: float, devise: str = "USD"):
    """Ajoute un gain dans le wallet interne selon la devise."""
    if montant > 0 and devise in ["USD", "EUR"]:
        wallet.add_gain(devise, montant)
        logging.info(f"Gain enregistré : {montant} {devise}")

        # Affichage automatique du solde total après gain
        total_usd = wallet.get_solde("USD")
        total_eur = wallet.get_solde("EUR")
        logging.info(f"Solde actuel du wallet : {total_usd} USD | {total_eur} EUR")
    else:
        logging.warning("Montant ou devise invalide pour enregistrer le gain.")

def retirer_gain(self, montant: float, devise: str = "USD"):
    """Retire un montant du wallet interne si disponible."""
    if montant > 0 and devise in ["USD", "EUR"]:
        if wallet.get_solde(devise) >= montant:
            wallet.retirer_gain(devise, montant)
            logging.info(f"Retrait effectué : {montant} {devise}")
        else:
            logging.warning(f"Fonds insuffisants pour retirer {montant} {devise}")
    else:
        logging.warning("Montant ou devise invalide pour retirer le gain.")
def initialiser_wallet(self):
        """Crée la table wallet si elle n'existe pas."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS wallet (
                    devise TEXT PRIMARY KEY,
                    solde REAL DEFAULT 0.0
                );
            """)
            conn.commit()
            logging.info("Table wallet vérifiée/créée.")

    def ajouter_gain(self, montant: float, devise: str = "USD"):
        """Ajoute un gain dans la base de données selon la devise."""
        if montant <= 0 or devise not in ["USD", "EUR"]:
            logging.warning("Montant ou devise invalide pour ajouter un gain.")
            return

        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT solde FROM wallet WHERE devise = ?;", (devise,))
            row = cursor.fetchone()
            if row:
                nouveau_solde = row[0] + montant
                cursor.execute("UPDATE wallet SET solde = ? WHERE devise = ?;", (nouveau_solde, devise))
            else:
                cursor.execute("INSERT INTO wallet (devise, solde) VALUES (?, ?);", (devise, montant))
            conn.commit()
            logging.info(f"Gain ajouté : {montant} {devise}")

    def obtenir_solde(self, devise: str = "USD") -> float:
        """Retourne le solde actuel de la devise."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT solde FROM wallet WHERE devise = ?;", (devise,))
            row = cursor.fetchone()
            return row[0] if row else 0.0

    def effectuer_transfert(self, montant: float, devise: str = "USD"):
        """Simule un retrait manuel du wallet interne."""
        if montant <= 0:
            logging.warning("Montant de transfert invalide.")
            return False

        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT solde FROM wallet WHERE devise = ?;", (devise,))
            row = cursor.fetchone()
            if not row or row[0] < montant:
                logging.warning("Fonds insuffisants pour le transfert.")
                return False

            nouveau_solde = row[0] - montant
            cursor.execute("UPDATE wallet SET solde = ? WHERE devise = ?;", (nouveau_solde, devise))
            conn.commit()
            logging.info(f"Transfert simulé de {montant} {devise}. Nouveau solde : {nouveau_solde} {devise}")
            return True
