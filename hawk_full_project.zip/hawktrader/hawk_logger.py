import logging
from logging.handlers import RotatingFileHandler
import os
from datetime import datetime

# Créer un dossier de logs s'il n'existe pas
LOG_DIR = "logs"
os.makedirs(LOG_DIR, exist_ok=True)

# Génère un nom de fichier de log dynamique par date
log_filename = os.path.join(LOG_DIR, f"hawk_log_{datetime.now().strftime('%Y-%m-%d')}.log")

# Configuration du logger
logger = logging.getLogger("HawkLogger")
logger.setLevel(logging.DEBUG)

# Gestionnaire de rotation : 1 Mo max par fichier, 5 sauvegardes
file_handler = RotatingFileHandler(log_filename, maxBytes=1_000_000, backupCount=5)
file_handler.setLevel(logging.DEBUG)

# Format de log
formatter = logging.Formatter(
    '[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
file_handler.setFormatter(formatter)

# Console (avec couleur si besoin)
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(formatter)

# Ajout des handlers
logger.addHandler(file_handler)
logger.addHandler(console_handler)

# Fonction utilitaire
def log_info(msg):
    logger.info(msg)

def log_warning(msg):
    logger.warning(msg)

def log_error(msg):
    logger.error(msg)

def log_debug(msg):
    logger.debug(msg)
hawk_logger = logger
