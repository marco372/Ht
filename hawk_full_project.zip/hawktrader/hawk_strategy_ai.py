import json
import os
from datetime import datetime
from random import random  # à remplacer par ton vrai modèle prédictif
from hawk_logger import hawk_logger

class StrategyAI:
    def __init__(self):
        self.history_file = "strategy_log.json"
        self.load_history()

    def load_history(self):
        if os.path.exists(self.history_file):
            with open(self.history_file, "r") as f:
                self.strategy_history = json.load(f)
        else:
            self.strategy_history = []

    def save_history(self):
        with open(self.history_file, "w") as f:
            json.dump(self.strategy_history, f, indent=4)

    def learn_from_history(self):
        """Optionnel : ajuste la stratégie selon les anciennes réussites."""
        successful = [entry for entry in self.strategy_history if entry.get("success")]
        if not successful:
            return {"default_confidence": 0.7}
        
        avg_conf = sum(entry.get("confidence", 0.7) for entry in successful) / len(successful)
        return {"default_confidence": round(avg_conf, 3)}

    def evaluate_trade(self, symbol, signal, confidence, sentiment_score, price_before, price_after):
        """Évalue si une stratégie a rapporté du bénéfice."""
        success = False
        if signal == "BUY" and price_after > price_before:
            success = True
        elif signal == "SELL" and price_after < price_before:
            success = True

        entry = {
            "datetime": datetime.utcnow().isoformat(),
            "symbol": symbol,
            "signal": signal,
            "confidence": confidence,
            "sentiment_score": sentiment_score,
            "price_before": price_before,
            "price_after": price_after,
            "success": success
        }
        self.strategy_history.append(entry)
        self.save_history()
        hawk_logger(f"Stratégie enregistrée pour {symbol} - Succès: {success}")

    def predict_action(self, symbol, sentiment_score):
        """Donne un signal de trading basé sur le sentiment."""
        if sentiment_score > 0.3:
            return "BUY", round(0.85 + random() * 0.1, 3)
        elif sentiment_score < -0.3:
            return "SELL", round(0.85 + random() * 0.1, 3)
        else:
            return "HOLD", round(0.4 + random() * 0.2, 3)
