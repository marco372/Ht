import telebot

bot = telebot.TeleBot("7691798027:AAHbYVBbVo3ZgZNLNEXTd7YRyI9LkhK7OBk")

@bot.message_handler(commands=['start'])
def start(msg):
    bot.reply_to(msg, "Bonjour, je suis bot_6 HawkTrader Telegram!")

print("Telegram bot_6 lancé...")
bot.polling()
