import telebot

bot = telebot.TeleBot("7960393627:AAE8yPDtqSGQXpKmU8F9dLfL4aQQ8_CZliA")

@bot.message_handler(commands=['start'])
def start(msg):
    bot.reply_to(msg, "Bonjour, je suis bot_5 HawkTrader Telegram!")

print("Telegram bot_5 lancé...")
bot.polling()
