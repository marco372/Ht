import telebot

bot = telebot.TeleBot("ok")

@bot.message_handler(commands=['start'])
def start(msg):
    bot.reply_to(msg, "Bonjour, je suis bot_7 HawkTrader Telegram!")

print("Telegram bot_7 lancé...")
bot.polling()
