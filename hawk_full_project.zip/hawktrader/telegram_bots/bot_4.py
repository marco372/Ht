import telebot

bot = telebot.TeleBot("8136706465:AAEFO0ou0W34U4g2uu0MNe-IZXWKEFQjhjw")

@bot.message_handler(commands=['start'])
def start(msg):
    bot.reply_to(msg, "Bonjour, je suis bot_4 HawkTrader Telegram!")

print("Telegram bot_4 lancé...")
bot.polling()
