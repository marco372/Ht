import telebot

bot = telebot.TeleBot("7680752328:AAFuj7F3U_3A-aQHzXWIiAWBpt9d0ocQQrU")

@bot.message_handler(commands=['start'])
def start(msg):
    bot.reply_to(msg, "Bonjour, je suis bot_2 HawkTrader Telegram!")

print("Telegram bot_2 lancé...")
bot.polling()
