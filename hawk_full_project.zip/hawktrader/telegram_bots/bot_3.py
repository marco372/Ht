import telebot

bot = telebot.TeleBot("7934428371:AAGsNYQnsXudJjgRwAyTdTrp5_x_nWai6qQ")

@bot.message_handler(commands=['start'])
def start(msg):
    bot.reply_to(msg, "Bonjour, je suis bot_3 HawkTrader Telegram!")

print("Telegram bot_3 lancé...")
bot.polling()
