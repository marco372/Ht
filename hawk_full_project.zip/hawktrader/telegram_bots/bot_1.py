import telebot

bot = telebot.TeleBot("7718708761:AAEZ9BoOurNxGWK2JktIzXSqahGLb09g_Dc")

@bot.message_handler(commands=['start'])
def start(msg):
    bot.reply_to(msg, "Bonjour, je suis bot_1 HawkTrader Telegram!")

print("Telegram bot_1 lancé...")
bot.polling()
